package com.dnd.ddv5diceroller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import java.io.FileInputStream;
import java.util.Random;
import android.widget.*;
import android.view.View;
import java.io.*;

public class MainActivity extends AppCompatActivity {
public String rolltree;
public int advantage = 0, disadvantage = 0;

    public int getRND(int dice) {

        int r1 = new Random().nextInt(dice) + 1;
        int r2 = new Random().nextInt(dice) + 1;

        if (advantage == 1 && dice == 20) { if (r2 > r1) { return r2; } }
        if (disadvantage == 1 && dice == 20) { if (r1 > r2) { return r2; } }

        return r1;
    }
    public int rollDice(String dice) {
        int[] roll = {1,0,0};
        int i=0,j=0,d=-1, result=0, sign=1;
        String mybuf,ddice;

//System.out.println("rollDice = " + dice);

        mybuf = dice;

        while (i < dice.length()) {
            if (mybuf.charAt(i) == 'D' || mybuf.charAt(i) == 'd') {
                if (i > 0) {
                    ddice = mybuf.substring(0, i);
// System.out.println("ddice = " + ddice + ":i = " + i);
                    roll[0] = Integer.parseInt(ddice);
                }
                j = i+1;
                d=i;
            } else if (mybuf.charAt(i) == '+' || mybuf.charAt(i) == '-') {
                ddice = mybuf.substring(i);
                roll[2] = Integer.parseInt(ddice);
                ddice = mybuf.substring(i+1); roll[1] = Integer.parseInt(ddice);
                if (mybuf.charAt(i) == '-') { sign = -1; }
            }
            i++;
        }
// System.out.println("1 rollDice = " + roll[0] + ":" + roll[1] + ":" + roll[2]);
        // check for a XdY string
        if (roll[1] == 0) {
            ddice = mybuf.substring(j);
            roll[1] = Integer.parseInt(ddice);
        }

        if (roll[0] == 0) {
            roll[0] = 1;
        }
// System.out.println("2 rollDice = " + roll[0] + ":" + roll[1] + ":" + roll[2]);

        if (d == -1) {
            result += Integer.parseInt(dice);
        } else {
            result += roll[2];
            while (roll[0] > 0) {
                result += getRND(roll[1]);
                roll[0] --;
            }
            if (result < 1) { result = 1; }
        }

        result *= sign;

//System.out.println("rollDice = " + roll[0] + ":" + roll[1] + ":" + roll[2] + " = " + result);

        return result;
    }

    public int parseDice(String dice) {
        int i=1, j=0, t=0, sign=1, val=0;
        String dicebuf, ddice;

            // some basic checks
        if (dice.length() < 1) { return 0; }
        dicebuf = dice.replaceAll("[1234567890dD\\+\\-\\s]", "");
        if (dicebuf.length() > 0) { return 0; }
            // remove any spaces
        dicebuf = dice.replaceAll("\\s+","");
//System.out.println("0parseDice = " + dicebuf);

        rolltree = "";

        while (i < dicebuf.length()) {
            if (dicebuf.charAt(i) == '+' || dicebuf.charAt(i) == '-') {
                ddice = dicebuf.substring(j, i);
                val = rollDice(ddice) * sign;
//System.out.println("1parseDice = " + ddice + " / " + j + " / " + i);
                t += val;
                if (val > 0) { rolltree = rolltree.concat("+" +String.valueOf(val)); }
                else { rolltree = rolltree.concat(String.valueOf(val)); }
                j = i+1;
                if (dicebuf.charAt(i) == '-') { sign = -1; }
                if (dicebuf.charAt(i) == '+') { sign = 1; }
            }
            i++;
        }

        ddice = dicebuf.substring(j);
//System.out.println("2parseDice = " + ddice + " / " + j + " / " + i);
        val = rollDice(ddice) * sign;
        t += val;
        if (val > 0) { rolltree = rolltree.concat("+" + String.valueOf(val)); }
        else { rolltree = rolltree.concat(String.valueOf(val)); }

        return t;
    }

    public void rollDice( int dice) {
            int i=1, j=0, r=0;
            String msg;

            msg = "Rolls: ";

            EditText fld = (EditText)findViewById(R.id.rollCount);
            if (fld.getText().toString().length() > 0) { i = Integer.parseInt(fld.getText().toString()); } else { fld.setText("1"); }
            if (i < 1) { i = 1; }
            for (int a=0; a<i; a++) {
                r = getRND(dice); j += r;
                msg += "" + Integer.toString(r);
                if (i > 1) { msg += "+"; }
            }
            fld = (EditText)findViewById(R.id.rollResult);
            if (dice == 20 && i == 1 && j == 20) { fld.setBackgroundColor(Color.GREEN); }
            else { fld.setBackgroundColor(Color.WHITE); }
            fld.setText(String.valueOf(j), TextView.BufferType.EDITABLE);
            fld = findViewById(R.id.RollResultOther); fld.setText("");
            fld = (EditText)findViewById(R.id.RollResultOther); fld.setText(msg);
    }

    public void doAttack(int line) {
        int attk=0, dam=0, roll=0, addattk, adddam;
        EditText AB, DAM;
        String chk;

        roll = getRND(20);
        if (line == 1) { AB = findViewById(R.id.WeaponAttkBonus1); DAM = findViewById(R.id.WeaponDamage1); }
        else if (line == 2) { AB = findViewById(R.id.WeaponAttkBonus2); DAM = findViewById(R.id.WeaponDamage2); }
        else if (line == 3) { AB = findViewById(R.id.WeaponAttkBonus3); DAM = findViewById(R.id.WeaponDamage3); }
        else { AB = findViewById(R.id.WeaponAttkBonus4); DAM = findViewById(R.id.WeaponDamage4); }

        try {
            attk = roll + Integer.parseInt(AB.getText().toString());
        } catch (Exception e) {
            attk = roll;
        }
        chk = DAM.getText().toString().replaceAll("[1234567890dD\\+\\-\\s]", "");
        if (chk.length() > 0) {
            DAM = findViewById(R.id.RollResultOther);
            DAM.setText("Bad dice: " + chk);
            return;
        }
        AB = findViewById(R.id.addToAttacks); addattk = parseDice(AB.getText().toString()); attk += addattk;
        AB = findViewById(R.id.addToDamage); adddam = parseDice(AB.getText().toString());
        dam += parseDice(DAM.getText().toString()) + adddam;

        AB = findViewById(R.id.rollResult);
        if (roll == 20) { dam *= 2; AB.setBackgroundColor(Color.GREEN); } else { AB.setBackgroundColor(Color.WHITE); }
        AB.setText(String.valueOf(attk) );
        DAM = findViewById(R.id.RollResultOther);
        if (roll == 20) { DAM.setText("Damage: " + String.valueOf(dam) + " (Crit: Dbl Damage)"); }
        else { DAM.setText("Damage: " + String.valueOf(dam)); }
    }

    public void doMisc(int line) {
        EditText DAM;
        int dam=0;
        String chk;

        if (line == 1) { DAM = findViewById(R.id.MiscDice1); }
        else if (line == 2) { DAM = findViewById(R.id.MiscDice2); }
        else if (line == 3) { DAM = findViewById(R.id.MiscDice3); }
        else { DAM = findViewById(R.id.MiscDice4); }

        chk = DAM.getText().toString().replaceAll("[1234567890dD\\+\\-\\s]", "");
        if (chk.length() > 0) {
            DAM = findViewById(R.id.RollResultOther);
            DAM.setText("Bad dice: " + chk);
            return;
        }
        dam = parseDice(DAM.getText().toString());

        DAM = findViewById(R.id.rollResult);
        DAM.setText("");

        DAM = findViewById(R.id.RollResultOther);
        DAM.setText(String.valueOf(dam));
    }
    public void saveData() {
        byte[] output;
        EditText fld;

        try {
            SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            fld = findViewById(R.id.WeaponName1); editor.putString("WeaponName1", fld.getText().toString());
            fld = findViewById(R.id.WeaponName2); editor.putString("WeaponName2", fld.getText().toString());
            fld = findViewById(R.id.WeaponName3); editor.putString("WeaponName3", fld.getText().toString());
            fld = findViewById(R.id.WeaponName4); editor.putString("WeaponName4", fld.getText().toString());
            fld = findViewById(R.id.WeaponAttkBonus1); editor.putString("WeaponAttkBonus1", fld.getText().toString());
            fld = findViewById(R.id.WeaponAttkBonus2); editor.putString("WeaponAttkBonus2", fld.getText().toString());
            fld = findViewById(R.id.WeaponAttkBonus3); editor.putString("WeaponAttkBonus3", fld.getText().toString());
            fld = findViewById(R.id.WeaponAttkBonus4); editor.putString("WeaponAttkBonus4", fld.getText().toString());
            fld = findViewById(R.id.WeaponDamage1); editor.putString("WeaponDamage1", fld.getText().toString());
            fld = findViewById(R.id.WeaponDamage2); editor.putString("WeaponDamage2", fld.getText().toString());
            fld = findViewById(R.id.WeaponDamage3); editor.putString("WeaponDamage3", fld.getText().toString());
            fld = findViewById(R.id.WeaponDamage4); editor.putString("WeaponDamage4", fld.getText().toString());
            fld = findViewById(R.id.MiscName1); editor.putString("MiscName1", fld.getText().toString());
            fld = findViewById(R.id.MiscName2); editor.putString("MiscName2", fld.getText().toString());
            fld = findViewById(R.id.MiscName3); editor.putString("MiscName3", fld.getText().toString());
            fld = findViewById(R.id.MiscName4); editor.putString("MiscName4", fld.getText().toString());
            fld = findViewById(R.id.MiscDice1); editor.putString("MiscDice1", fld.getText().toString());
            fld = findViewById(R.id.MiscDice2); editor.putString("MiscDice2", fld.getText().toString());
            fld = findViewById(R.id.MiscDice3); editor.putString("MiscDice3", fld.getText().toString());
            fld = findViewById(R.id.MiscDice4); editor.putString("MiscDice4", fld.getText().toString());
            fld = findViewById(R.id.addToAttacks); editor.putString("addToAttacks", fld.getText().toString());
            fld = findViewById(R.id.addToDamage); editor.putString("addToDamage", fld.getText().toString());
            fld = findViewById(R.id.miscCounter1); editor.putString("miscCounter1", fld.getText().toString());
            fld = findViewById(R.id.miscCounter2); editor.putString("miscCounter2", fld.getText().toString());
            editor.commit();
        } catch (Exception e) {
            // fld = findViewById(R.id.outputMesg); fld.setText(e.getMessage());
        }
    }

    public void loadData() {
        byte[] input;
        EditText fld;
        String line="";
        SharedPreferences sharedPreferences;

        try {
            sharedPreferences = getPreferences(MODE_PRIVATE);
            line = sharedPreferences.getString("WeaponName1", ""); fld = findViewById(R.id.WeaponName1); fld.setText(line);
            line = sharedPreferences.getString("WeaponName2", ""); fld = findViewById(R.id.WeaponName2); fld.setText(line);
            line = sharedPreferences.getString("WeaponName3", ""); fld = findViewById(R.id.WeaponName3); fld.setText(line);
            line = sharedPreferences.getString("WeaponName4", ""); fld = findViewById(R.id.WeaponName4); fld.setText(line);
            line = sharedPreferences.getString("WeaponAttkBonus1", ""); fld = findViewById(R.id.WeaponAttkBonus1); fld.setText(line);
            line = sharedPreferences.getString("WeaponAttkBonus2", ""); fld = findViewById(R.id.WeaponAttkBonus2); fld.setText(line);
            line = sharedPreferences.getString("WeaponAttkBonus3", ""); fld = findViewById(R.id.WeaponAttkBonus3); fld.setText(line);
            line = sharedPreferences.getString("WeaponAttkBonus4", ""); fld = findViewById(R.id.WeaponAttkBonus4); fld.setText(line);
            line = sharedPreferences.getString("WeaponDamage1", ""); fld = findViewById(R.id.WeaponDamage1); fld.setText(line);
            line = sharedPreferences.getString("WeaponDamage2", ""); fld = findViewById(R.id.WeaponDamage2); fld.setText(line);
            line = sharedPreferences.getString("WeaponDamage3", ""); fld = findViewById(R.id.WeaponDamage3); fld.setText(line);
            line = sharedPreferences.getString("WeaponDamage4", ""); fld = findViewById(R.id.WeaponDamage4); fld.setText(line);
            line = sharedPreferences.getString("MiscName1", ""); fld = findViewById(R.id.MiscName1); fld.setText(line);
            line = sharedPreferences.getString("MiscName2", ""); fld = findViewById(R.id.MiscName2); fld.setText(line);
            line = sharedPreferences.getString("MiscName3", ""); fld = findViewById(R.id.MiscName3); fld.setText(line);
            line = sharedPreferences.getString("MiscName4", ""); fld = findViewById(R.id.MiscName4); fld.setText(line);
            line = sharedPreferences.getString("MiscDice1", ""); fld = findViewById(R.id.MiscDice1); fld.setText(line);
            line = sharedPreferences.getString("MiscDice2", ""); fld = findViewById(R.id.MiscDice2); fld.setText(line);
            line = sharedPreferences.getString("MiscDice3", ""); fld = findViewById(R.id.MiscDice3); fld.setText(line);
            line = sharedPreferences.getString("MiscDice4", ""); fld = findViewById(R.id.MiscDice4); fld.setText(line);
            line = sharedPreferences.getString("addToAttacks", ""); fld = findViewById(R.id.addToAttacks); fld.setText(line);
            line = sharedPreferences.getString("addToDamage", ""); fld = findViewById(R.id.addToDamage); fld.setText(line);
            line = sharedPreferences.getString("miscCounter1", "0"); fld = findViewById(R.id.miscCounter1); fld.setText(line);
            line = sharedPreferences.getString("miscCounter2", "0"); fld = findViewById(R.id.miscCounter2); fld.setText(line);
        } catch (Exception e) {
            //fld = findViewById(R.id.outputMesg); fld.setText(e.getMessage());
       }
    }
    public void doDisadvantage() {
        Button but = findViewById(R.id.setDisadvantage);
        if (disadvantage == 1) { disadvantage = 0; but.setBackgroundColor(Color.WHITE); }
        else if (disadvantage == 0) {
            disadvantage = 1; but.setBackgroundColor(Color.RED);
            if (advantage == 1) {
                advantage = 0;
                but = findViewById(R.id.setAdvantage);
                but.setBackgroundColor(Color.WHITE);
            }
        }
    }

    public void doAdvantage() {
        Button but = findViewById(R.id.setAdvantage);
        if (advantage == 1) { advantage = 0; but.setBackgroundColor(Color.WHITE); }
        else if (advantage == 0) {
            advantage = 1; but.setBackgroundColor(Color.RED);
            if (disadvantage == 1) {
                disadvantage = 0;
                but = findViewById(R.id.setDisadvantage);
                but.setBackgroundColor(Color.WHITE);
            }
        }
    }
    public void buttonPress(View v) {
        int id;
        EditText fld, fld2;
        id = v.getId();

        if (id == R.id.rolld20) { rollDice(20); }
        else if (id == R.id.rolld12) { rollDice(12); }
        else if (id == R.id.rolld10) { rollDice(10); }
        else if (id == R.id.rolld8) { rollDice(8); }
        else if (id == R.id.rolld6) { rollDice(6); }
        else if (id == R.id.rolld4) { rollDice(4); }
        else if (id == R.id.MiscRoll1) { doMisc(1); }
        else if (id == R.id.MiscRoll2) { doMisc(2); }
        else if (id == R.id.MiscRoll3) { doMisc(3); }
        else if (id == R.id.MiscRoll4) { doMisc(4); }
        else if (id == R.id.WeaponAttack1) { doAttack(1); }
        else if (id == R.id.WeaponAttack2) { doAttack(2); }
        else if (id == R.id.WeaponAttack3) { doAttack(3); }
        else if (id == R.id.WeaponAttack4) { doAttack(4); }
        else if (id == R.id.setDisadvantage) { doDisadvantage(); }
        else if (id == R.id.setAdvantage) { doAdvantage(); }
        else if (id == R.id.saveData) {
            fld = findViewById(R.id.WeaponName1);
            fld2 = findViewById(R.id.WeaponName2);
            // check to see if it is blank or not
            if (fld.getText().length() == 0 && fld2.getText().length() == 0) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
                builder.setMessage("Do you really want to save?")
                        .setTitle("Save Data");
                builder.setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface dialog, int id) {
                        saveData();
                    }
                });
                android.app.AlertDialog dialog = builder.create();
                dialog.show();
            } else {
                saveData();
            }
        }
        else if (id == R.id.loadData) { loadData(); }
    }

            @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
